import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class UserService {
  static const _nicknameKey = 'userNickname';

  static Future<String> fetchNicknameByEmail(String email) async {
    final prefs = await SharedPreferences.getInstance();
    // 이메일을 기준으로 저장된 닉네임 캐시 키를 생성
    final cacheKey = '$_nicknameKey:$email';
    final cachedNickname = prefs.getString(cacheKey);

    if (cachedNickname != null) {
      // 캐시에서 닉네임을 찾았으면 바로 반환
      return cachedNickname;
    } else {
      // 캐시에 닉네임이 없으면 서버에서 가져온다
      var url = Uri.parse('https://yourserver.com/api/nickname?email=$email');
      var response = await http.get(url);

      if (response.statusCode == 200) {
        var jsonResponse = json.decode(response.body);
        final nickname = jsonResponse['nickname'];
        // 닉네임을 로컬 스토리지에 저장
        await prefs.setString(cacheKey, nickname);
        return nickname;
      } else {
        throw Exception('Failed to load nickname from the server');
      }
    }
  }
}
