class UserIntroductionRepository {
  // 사용자 소개글을 임시로 저장하는 변수
  String? introduction;

  void saveIntroduction(String intro) {
    introduction = intro;
  }

  String? getIntroduction() {
    return introduction;
  }
}
