import 'dart:io';
import 'package:image_picker/image_picker.dart';

class UserProfileRepository {
  // 임시로 프로필 이미지 파일을 저장하는 변수
  XFile? profileImage;

  Future<void> pickImageFromGallery() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      profileImage = image;
    }
  }

  XFile? getProfileImage() {
    return profileImage;
  }
}
