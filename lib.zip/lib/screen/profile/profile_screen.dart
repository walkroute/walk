import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../main_screen.dart';
import '../../repository/profile_image_repository.dart';
import '../../repository/introduction_repository.dart';


class ProfileScreen extends StatefulWidget {
  @override
  _ProfilePictureScreenState createState() => _ProfilePictureScreenState();
}

class _ProfilePictureScreenState extends State<ProfileScreen> {
  final UserProfileRepository _profileRepo = UserProfileRepository();
  final UserIntroductionRepository _introRepo = UserIntroductionRepository();
  final TextEditingController _introController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _introController.text = _introRepo.getIntroduction() ?? '';
  }

  Future<void> _pickImage() async {
    await _profileRepo.pickImageFromGallery();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    XFile? profileImage = _profileRepo.getProfileImage();

    return Scaffold(
      appBar: AppBar(
        title: Text('프로필 설정'),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 20), // 상단 여백
          CircleAvatar(
            radius: 120, // 반지름을 120으로 변경하여 프로필 사진의 크기를 더 크게 조정
            backgroundImage: profileImage != null ? FileImage(File(profileImage.path)) : null,
            backgroundColor: Colors.grey.shade200, // 프로필 이미지가 없을 경우의 배경 색상
          ),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(right: 16.0),
                        child: FloatingActionButton(
                          onPressed: _pickImage,
                          child: Icon(Icons.camera_alt, size: 30), // 아이콘 크기 조정
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: EdgeInsets.all(16.0),
                    child: TextField(
                      controller: _introController,
                      decoration: InputDecoration(
                        labelText: '소개',
                        hintText: '본인 소개를 입력하세요',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                    child: ElevatedButton(
                      child: Text('확인'),
                      onPressed: () {
                        _introRepo.saveIntroduction(_introController.text);
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (context) => MainPage()), // MainPage의 실제 경로 확인 필요
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        backgroundColor: Colors.white,
                        minimumSize: Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                          side: BorderSide(color: Colors.black),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}