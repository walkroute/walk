import 'package:flutter/material.dart';

class MeetingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // 여기에 모임 리스트를 불러오는 로직을 구현합니다.
    return ListView.builder(
      itemCount: 20, // 예시 데이터의 수
      itemBuilder: (context, index) {
        return ListTile(
          leading: Icon(Icons.group),
          title: Text('모임 이름 $index'),
          subtitle: Text('모임 설명 등 추가 정보'),
        );
      },
    );
  }
}
