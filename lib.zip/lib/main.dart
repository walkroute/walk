import 'package:flutter/material.dart';
import '/splash/splashFirst.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  await Hive.initFlutter();
  await Hive.openBox<Map<String, dynamic>>('events');
  initializeDateFormatting('ko_KR', null).then((_) => runApp(MyApp()));
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '뚜벅뚜벅',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: SplashScreen(), // 첫 번째로 보여질 스플래시 화면
    );
  }
}
